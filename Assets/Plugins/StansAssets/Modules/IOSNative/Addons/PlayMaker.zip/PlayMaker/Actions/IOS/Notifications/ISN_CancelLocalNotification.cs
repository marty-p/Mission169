﻿using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Notifications")]
	public class ISN_CancelLocalNotification : FsmStateAction {
		
		public FsmInt notificationId;
		
		public override void OnEnter() {
			IOSNotificationController.instance.CancelLocalNotificationById(notificationId.Value);
			Finish();
		}
	}
}


