﻿using UnityEngine;
using System.Collections;
using HutongGames.PlayMaker;

namespace HutongGames.PlayMaker.Actions {
		
	[ActionCategory("IOS Native - Notifications")]
	public class ISN_RegisterForRemoteNotifications : FsmStateAction {

		public FsmString deviceToken;

		#if UNITY_IPHONE
		public UnityEngine.iOS.NotificationType type;
		#endif
	
		public override void OnEnter() {
			#if UNITY_IPHONE

			IOSNotificationController.OnDeviceTokenReceived += OnDeviceTokenReceived;
			IOSNotificationController.Instance.RegisterForRemoteNotifications (type);
			#endif
		}

		private void OnDeviceTokenReceived(IOSNotificationDeviceToken token) {
			#if UNITY_IPHONE
			IOSNotificationController.OnDeviceTokenReceived -= OnDeviceTokenReceived;
		
			deviceToken = token.tokenString;
			Finish ();
			#endif
		}
	}
}





