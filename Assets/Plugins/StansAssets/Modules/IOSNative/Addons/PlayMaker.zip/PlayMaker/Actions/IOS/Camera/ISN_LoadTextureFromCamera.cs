using UnityEngine;
using System.Collections;


namespace HutongGames.PlayMaker.Actions {
	
	[ActionCategory("IOS Native - Camera")]
	public class ISN_LoadTextureFromGallery : FsmStateAction {

		public FsmTexture LoadedTexture;
		public FsmEvent loaded;
		public FsmEvent fail;


		
		public override void OnEnter() {
			IOSCamera.OnImagePicked += OnImage;
			IOSCamera.Instance.PickImage(ISN_ImageSource.Camera);

			#if UNITY_EDITOR
				Fsm.Event(fail);
				Finish();
			#endif

		}


		private void OnImage (IOSImagePickResult result) {
			if(result.IsSucceeded) {
				LoadedTexture.Value = result.Image;
				Fsm.Event(loaded);
			} else {
				Fsm.Event(fail);
			}
			Finish();
		}

	}
}



